import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.Card
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import java.util.*

// Clase principal que contendrá toda la lógica y la UI
object OrganigramaApp {

    // Clase para representar un Empleado/Rol en el Organigrama (Nodo del Árbol)
    data class Empleado(
        val id: Int, // Añadimos ID para mapear con la BD
        val nombre: String,
        val rol: String,
        val idJefe: Int?, // ID del jefe, puede ser nulo para el CEO
        val subordinados: MutableList<Empleado> = mutableListOf() // Lista de hijos
    )

    // Configuración de la conexión a la base de datos
    private const val DB_URL = "jdbc:mysql://localhost:3306/organigrama_db"
    private const val DB_USER = "root" // Cambia si tu usuario de MySQL es diferente
    private const val DB_PASSWORD = "12345" // Cambia por tu contraseña de MySQL

    // Función para obtener la conexión a la base de datos
    private fun getConnection(): Connection? {
        return try {
            val props = Properties()
            props["user"] = DB_USER
            props["password"] = DB_PASSWORD
            DriverManager.getConnection(DB_URL, props)
        } catch (e: SQLException) {
            println("Error al conectar a la base de datos: ${e.message}")
            null
        }
    }

    // Función para cargar los empleados desde la base de datos
    private suspend fun cargarEmpleadosDesdeBD(): List<Empleado> = withContext(Dispatchers.IO) {
        val empleados = mutableListOf<Empleado>()
        getConnection()?.use { conn ->
            val query = "SELECT id, nombre, rol, id_jefe FROM empleados ORDER BY id ASC"
            conn.createStatement().use { stmt ->
                stmt.executeQuery(query).use { rs ->
                    while (rs.next()) {
                        empleados.add(
                            Empleado(
                                id = rs.getInt("id"),
                                nombre = rs.getString("nombre"),
                                rol = rs.getString("rol"),
                                idJefe = rs.getInt("id_jefe").takeIf { !rs.wasNull() } // Manejo de NULL en id_jefe
                            )
                        )
                    }
                }
            }
        } ?: println("No se pudo establecer la conexión a la base de datos.")
        empleados
    }

    // Función para construir el organigrama (árbol) a partir de la lista plana de empleados
    private fun construirOrganigrama(empleadosFlat: List<Empleado>): Empleado? {
        if (empleadosFlat.isEmpty()) return null

        val empleadoMap = empleadosFlat.associateBy { it.id } // Mapa para acceso rápido por ID
        val rootEmpleado = empleadosFlat.find { it.idJefe == null } // Buscar al CEO (sin jefe)

        // Si no hay CEO, no podemos construir el organigrama
        if (rootEmpleado == null) {
            println("Error: No se encontró un empleado raíz (CEO) sin jefe en la base de datos.")
            return null
        }

        // Construir la jerarquía
        empleadosFlat.forEach { empleado ->
            if (empleado.idJefe != null) {
                empleadoMap[empleado.idJefe]?.subordinados?.add(empleado)
            }
        }
        return rootEmpleado
    }

    // Composable para mostrar un solo empleado
    @Composable
    fun EmpleadoCard(empleado: Empleado, level: Int = 0) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = (level * 24).dp, top = 8.dp, end = 8.dp, bottom = 0.dp), // Indentación para jerarquía
            elevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .background(color = if (level == 0) MaterialTheme.colors.primary else MaterialTheme.colors.surface)
            ) {
                Text(text = empleado.nombre, style = MaterialTheme.typography.h6, color = if (level == 0) Color.White else Color.Black)
                Text(text = empleado.rol, style = MaterialTheme.typography.body2, color = if (level == 0) Color.White else Color.Black)
            }
        }
    }

    // Composable recursivo para mostrar el organigrama
    @Composable
    fun Organigrama(empleado: Empleado, level: Int = 0) {
        EmpleadoCard(empleado = empleado, level = level)

        // Mostrar subordinados recursivamente
        // Asegúrate de que los subordinados estén ordenados para una visualización consistente
        empleado.subordinados.sortedBy { it.nombre }.forEach { subordinado ->
            Organigrama(empleado = subordinado, level = level + 1)
        }
    }

    // Función principal de la aplicación
    @JvmStatic
    fun main(args: Array<String>) = application {
        // Estado para almacenar el organigrama cargado y el estado de carga
        var organigramaRoot by remember { mutableStateOf<Empleado?>(null) }
        var isLoading by remember { mutableStateOf(true) }
        var errorMessage by remember { mutableStateOf<String?>(null) }

        // Efecto para cargar los datos cuando el componente se compone por primera vez
        LaunchedEffect(Unit) {
            launch {
                try {
                    isLoading = true
                    val empleadosFlat = cargarEmpleadosDesdeBD()
                    if (empleadosFlat.isNotEmpty()) {
                        organigramaRoot = construirOrganigrama(empleadosFlat)
                        if (organigramaRoot == null) {
                            errorMessage = "Error al construir el organigrama: No se encontró un CEO o estructura inválida."
                        }
                    } else {
                        errorMessage = "No se encontraron empleados en la base de datos."
                    }
                } catch (e: Exception) {
                    errorMessage = "Error al cargar datos: ${e.message}"
                    println("Excepción durante la carga de datos: $e")
                } finally {
                    isLoading = false
                }
            }
        }

        Window(onCloseRequest = ::exitApplication, title = "Organigrama de la Empresa (Desde DB)") {
            MaterialTheme {
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Organigrama de la Empresa (Desde DB)",
                        style = MaterialTheme.typography.h4,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    if (isLoading) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                            Text("Cargando organigrama...", modifier = Modifier.padding(top = 60.dp))
                        }
                    } else if (errorMessage != null) {
                        Text(
                            text = "Error: $errorMessage",
                            color = MaterialTheme.colors.error,
                            style = MaterialTheme.typography.h6,
                            modifier = Modifier.padding(16.dp)
                        )
                    } else if (organigramaRoot != null) {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            item {
                                Organigrama(empleado = organigramaRoot!!)
                            }
                        }
                    } else {
                        Text(
                            text = "No hay datos de organigrama disponibles.",
                            style = MaterialTheme.typography.h6,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }
    }

    // Preview para Compose (opcional, útil para desarrollo)
    @Preview
    @Composable
    fun PreviewOrganigrama() {
        MaterialTheme {
            val ceo = Empleado(1, "Juan Pérez", "CEO", null)
            val director = Empleado(2, "Ana García", "Directora", 1)
            val empleado = Empleado(3, "Luis Soto", "Empleado", 2)
            ceo.subordinados.add(director)
            director.subordinados.add(empleado)
            Organigrama(empleado = ceo)
        }
    }
}