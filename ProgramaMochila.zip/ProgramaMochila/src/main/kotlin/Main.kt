import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application

fun main() = application {
    Window(onCloseRequest = ::exitApplication, title = "Problema de la Mochila") {
        KnapsackApp()
    }
}

@Composable
@Preview
fun KnapsackApp() {
    var capacityInput by remember { mutableStateOf("") }
    var weightsInput by remember { mutableStateOf("") }
    var valuesInput by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    MaterialTheme {
        Column(
            modifier = Modifier.fillMaxSize().padding(15.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Problema de la Mochila", style = MaterialTheme.typography.h4)
            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = capacityInput,
                onValueChange = { capacityInput = it },
                label = { Text("Capacidad de la Mochila") },
                modifier = Modifier.fillMaxWidth(0.7f)
            )
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = weightsInput,
                onValueChange = { weightsInput = it },
                label = { Text("Pesos (separados por comas)") },
                modifier = Modifier.fillMaxWidth(0.7f)
            )
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = valuesInput,
                onValueChange = { valuesInput = it },
                label = { Text("Valores (separados por comas)") },
                modifier = Modifier.fillMaxWidth(0.7f)
            )
            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    error = ""
                    result = ""
                    try {
                        val capacity = capacityInput.toInt()
                        val weights = weightsInput.split(",").map { it.trim().toInt() }
                        val values = valuesInput.split(",").map { it.trim().toInt() }

                        if (weights.size != values.size) {
                            error = "Error: El número de pesos y valores debe ser el mismo."
                        } else if (weights.any { it <= 0 } || values.any { it < 0 } || capacity <= 0) {
                            error = "Error: Pesos y capacidad deben ser positivos. Valores deben ser no negativos."
                        } else {
                            val (maxValue, selectedItemIndices) = solveKnapsack(capacity, weights, values)
                            
                            val selectedItemsFormatted = if (selectedItemIndices.isNotEmpty()) {
                                selectedItemIndices.joinToString(separator = "\n") { index ->
                                    "- Ítem ${index + 1} (Peso: ${weights[index]}, Valor: ${values[index]}, Cantidad: 1)"
                                }
                            } else {
                                "Ninguno"
                            }

                            result = "Valor Máximo: $maxValue\n\nItems Seleccionados:\n$selectedItemsFormatted"
                        }
                    } catch (e: NumberFormatException) {
                        error = "Error de formato: Asegúrate de introducir números válidos."
                    } catch (e: Exception) {
                        error = "Ha ocurrido un error inesperado: ${e.localizedMessage}"
                    }
                },
                modifier = Modifier.fillMaxWidth(0.5f)
            ) {
                Text("Resolver")
            }
            Spacer(Modifier.height(20.dp))

            if (result.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(0.8f).padding(8.dp),
                    elevation = 4.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(result, style = MaterialTheme.typography.body1)
                    }
                }
            }

            if (error.isNotEmpty()) {
                Text(
                    text = error,
                    color = MaterialTheme.colors.error,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}

fun solveKnapsack(capacity: Int, weights: List<Int>, values: List<Int>): Pair<Int, List<Int>> {
    val n = weights.size
    val dp = Array(n + 1) { IntArray(capacity + 1) }

    for (i in 1..n) {
        for (w in 1..capacity) {
            val currentWeight = weights[i - 1]
            val currentValue = values[i - 1]

            if (currentWeight > w) {
                dp[i][w] = dp[i - 1][w]
            } else {
                dp[i][w] = maxOf(dp[i - 1][w], currentValue + dp[i - 1][w - currentWeight])
            }
        }
    }

    val selectedItems = mutableListOf<Int>()
    var currentCapacity = capacity
    for (i in n downTo 1) {
        if (dp[i][currentCapacity] != dp[i - 1][currentCapacity]) {
            selectedItems.add(i - 1)
            currentCapacity -= weights[i - 1]
        }
    }
    selectedItems.reverse()

    return Pair(dp[n][capacity], selectedItems)
}