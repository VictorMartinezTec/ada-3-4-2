import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
//import kotlin.math.max

data class Job(val id: String, val deadline: Int, val profit: Int)

fun main() = application {
    Window(onCloseRequest = ::exitApplication, title = "Job Sequencing") {
        JobSequencingApp()
    }
}

@Composable
fun JobSequencingApp() {
    var jobsInput by remember { mutableStateOf("") }
    var resultJobs by remember { mutableStateOf<List<Job>>(emptyList()) }
    var totalProfit by remember { mutableStateOf(0) }
    var errorMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Job Sequencing") })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = "Ingresa los trabajos en formato: ID,Deadline,Profit;ID,Deadline,Profit",
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            OutlinedTextField(
                value = jobsInput,
                onValueChange = { jobsInput = it },
                label = { Text("Ej: A,2,100;B,1,50;C,2,70;D,1,20;E,3,80") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    try {
                        val parsedJobs = parseJobsInput(jobsInput)
                        if (parsedJobs.isEmpty()) {
                            errorMessage = "No se encontraron trabajos válidos."
                            resultJobs = emptyList()
                            totalProfit = 0
                        } else {
                            val maxDeadline = parsedJobs.maxOfOrNull { it.deadline } ?: 0

                            if (maxDeadline == 0) {
                                errorMessage = "El deadline máximo es cero o no se pueden procesar trabajos sin deadline válido."
                                resultJobs = emptyList()
                                totalProfit = 0
                            } else {
                                val (scheduledJobs, profit) = solveJobSequencing(parsedJobs, maxDeadline)
                                resultJobs = scheduledJobs
                                totalProfit = profit
                                errorMessage = ""
                            }
                        }
                    } catch (e: Exception) {
                        errorMessage = "Error al parsear la entrada: ${e.message}"
                        resultJobs = emptyList()
                        totalProfit = 0
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Resolver")
            }

            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (resultJobs.isNotEmpty()) {
                Text(
                    text = "Trabajos seleccionados:",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(resultJobs) { job ->
                        Card(
                            elevation = 4.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("ID: ${job.id}")
                                Text("Deadline: ${job.deadline}")
                                Text("Profit: ${job.profit}")
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Beneficio Total: $totalProfit",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colors.primary
                )
            }
        }
    }
}

private fun parseJobsInput(input: String): List<Job> {
    return input.split(";")
        .mapNotNull { it.trim() }
        .filter { it.isNotEmpty() }
        .map { jobString ->
            val parts = jobString.split(",")
            if (parts.size == 3) {
                try {
                    val id = parts[0].trim()
                    val deadline = parts[1].trim().toInt()
                    val profit = parts[2].trim().toInt()
                    Job(id, deadline, profit)
                } catch (e: NumberFormatException) {
                    throw IllegalArgumentException("Formato numérico inválido en: $jobString")
                }
            } else {
                throw IllegalArgumentException("Formato de trabajo incorrecto: $jobString. Esperado: ID,Deadline,Profit")
            }
        }
}

private fun solveJobSequencing(jobs: List<Job>, maxDeadline: Int): Pair<List<Job>, Int> {
    // Ordenar los trabajos por beneficio en orden descendente.
    val sortedJobsByProfitDesc = jobs.sortedByDescending { it.profit }

    // Crear un array booleano para representar los slots de tiempo.
    val timeSlots = BooleanArray(maxDeadline + 1) { false }
    val finalScheduledJobs = mutableListOf<Job>()
    var currentTotalProfit = 0

    // Iterar a través de los trabajos ordenados.
    for (job in sortedJobsByProfitDesc) {
        for (i in job.deadline downTo 1) {
            if (!timeSlots[i]) {
                timeSlots[i] = true
                finalScheduledJobs.add(job)
                currentTotalProfit += job.profit
                break
            }
        }
    }

    finalScheduledJobs.sortBy { it.id }

    return Pair(finalScheduledJobs, currentTotalProfit)
}